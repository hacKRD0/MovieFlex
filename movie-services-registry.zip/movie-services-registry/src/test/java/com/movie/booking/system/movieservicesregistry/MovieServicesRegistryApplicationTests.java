package com.movie.booking.system.movieservicesregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieServicesRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
