package com.movie.booking.system.movieservicesregistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServicesRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieServicesRegistryApplication.class, args);
	}

}
